===================================
MesonSDK
===================================

## [1.0.0-beta4] - 2021-03-23
-------------

### Bug Fixes


## [1.0.0-beta3] - 2021-12-13
-------------

### Added Features
    - Added support for custom adapter

### Bug Fixes
    
    
## [1.0.0-beta2] - 2021-11-22
-------------

### Added Features
    - Support for Impression-Level Revenue Data (ILRD)
    - Added Analytics events.


## [1.0.0-beta1] - 2021-11-09
-------------

### Added Features
    - Added support for ad formats
        ○ Banner
        ○ Interstitial
        ○ Rewarded Video
        ○ Native (China only)
        ○ Splash (China only)
    - Ability to manage waterfall 
    - Ability to manage Ad Lifecycle
