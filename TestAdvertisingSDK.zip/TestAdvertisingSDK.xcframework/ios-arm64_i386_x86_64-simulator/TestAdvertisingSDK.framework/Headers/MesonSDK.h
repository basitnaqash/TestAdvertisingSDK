//
//  MesonSDK.h
//  MesonSDK
//
//  Created by Aaditya Gandhi on 25/08/20.
//  Copyright © 2020 InMobi. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MesonSDK.
FOUNDATION_EXPORT double MesonSDKVersionNumber;

//! Project version string for MesonSDK.
FOUNDATION_EXPORT const unsigned char MesonSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MesonSDK/PublicHeader.h>


